# 1 - Import library
import pygame
from pygame.locals import *
import sys

BLACKISH = (10, 10, 10)
WINDOW_WIDTH = 640
WINDOW_HEIGHT = 480
FRAMES_PER_SECOND = 30

# 2 - Initialize pygame
pygame.init()
screen= pygame.display.set_mode([WINDOW_WIDTH, WINDOW_HEIGHT])
 
# 3 - Load image(s)
ball = pygame.image.load("images/ball.gif")
ballRect =  ball.get_rect()
xSpeed = 3
ySpeed = 3

clock = pygame.time.Clock()  # set the speed (frames per second)

 
# 4 - Loop forever
while True:

    # 5 - loop through the events
    for event in pygame.event.get():
        # check if the event is the X button 
        if event.type == pygame.QUIT:
            # if it is quit the game
            pygame.quit()
            sys.exit()
    
    # 6 - clear the screen before drawing it again
    screen.fill(BLACKISH)
    
    # 7 - draw the screen elements

    if (ballRect.left < 0) or (ballRect.right > WINDOW_WIDTH):
        xSpeed = -xSpeed

    if (ballRect.top < 0) or (ballRect.bottom > WINDOW_HEIGHT):
        ySpeed = -ySpeed


    # update the rectangle of the ball, based on the speed in two directions
    ballRect.left = ballRect.left + xSpeed
    ballRect.top = ballRect.top + ySpeed

    #  Could alternatively be written as:      ballRect = ballRect.move(xSpeed, ySpeed)

    #print ballRect
    screen.blit(ball, ballRect)


    # 8 - update the screen
    pygame.display.update()

    # 9 slow things down a bit
    clock.tick(FRAMES_PER_SECOND)  # make PyGame wait the correct amount


